# Agrinho-2024
Inspirado pelo tema proposto para o concurso de 2024: Agrinho, do campo a cidade.

O site foi desenvolvido pensando em transmitir a ideia de que a arte pode ser contemplada em todos os espaços, seja no campo ou na cidade.
